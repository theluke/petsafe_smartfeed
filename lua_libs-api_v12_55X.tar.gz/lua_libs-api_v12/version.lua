local version = {
  rpc = rpc_version(),
  api = 12,
}

return version
